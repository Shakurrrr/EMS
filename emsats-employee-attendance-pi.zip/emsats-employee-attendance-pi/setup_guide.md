# Setup Guide for EMSATS Attendance System

## Hardware Setup
- Raspberry Pi 4
- PiCamera (or USB Camera)
- I2C LCD 16x2
- Buttons for Check-in / Check-out
- Red and Green LEDs
- MicroSD card (32GB recommended)
- Power Supply

## Software Setup
1. Install Raspberry Pi OS (Bookworm)
2. Enable I2C, Camera in raspi-config
3. Update system:

```bash
sudo apt update && sudo apt upgrade -y
```

4. Clone this repo:

```bash
git clone https://github.com/Shakurrrr/emsats-employee-attendance-pi.git
cd emsats-employee-attendance-pi
```

5. Install dependencies:

```bash
pip install -r requirements.txt
```

6. Configure PostgreSQL connection in `main.py`

7. Run the system:

```bash
python3 main.py
```

## Notes
- Auto scheduler runs daily and weekly updates
- Offline records saved in `unsynced_records.xlsx`