# EMSATS - Employee Attendance System (Raspberry Pi)

Hardware attendance system using facial recognition and PostgreSQL backend — developed as part of EMSATS (Employee Management System for Asataura Technology Services).

## Features
- Raspberry Pi 4 with PiCamera
- Facial recognition using OpenCV and face_recognition
- Offline logging with PostgreSQL database
- LCD display + buttons + LEDs
- Scheduled weekly and monthly reporting
- Offline sync for unsynced records
- Part of EMSATS project — FastAPI backend integration

## Hardware
- Raspberry Pi 4 (or 3)
- PiCamera V2 or USB Camera
- I2C LCD 16x2
- Push buttons
- LEDs (Red/Green)
- MicroSD card
- Power supply

## Software
- Python 3.11
- FastAPI backend (remote)
- PostgreSQL
- APScheduler
- RPLCD
- face_recognition
- OpenCV
- Pandas

## Setup Instructions
See [setup_guide.md](setup_guide.md)

## Progress
- [x] Hardware setup and wiring
- [x] Face recognition working on Pi
- [x] PostgreSQL connected
- [x] Scheduler integrated
- [ ] Test with full EMSATS backend API
- [ ] Final packaging for office deployment

## How to run

```bash
git clone https://github.com/Shakurrrr/emsats-employee-attendance-pi.git
cd emsats-employee-attendance-pi
pip install -r requirements.txt
python3 main.py
```

## Author
Yusuf Shehu — Hardware Project Developer, EMSATS  
[GitHub](https://github.com/Shakurrrr) | [LinkedIn](https://linkedin.com/in/yusuf-shehu)